# BLink2

[![CI Status](https://img.shields.io/travis/IGitGotIt/BLink2.svg?style=flat)](https://travis-ci.org/IGitGotIt/BLink2)
[![Version](https://img.shields.io/cocoapods/v/BLink2.svg?style=flat)](https://cocoapods.org/pods/BLink2)
[![License](https://img.shields.io/cocoapods/l/BLink2.svg?style=flat)](https://cocoapods.org/pods/BLink2)
[![Platform](https://img.shields.io/cocoapods/p/BLink2.svg?style=flat)](https://cocoapods.org/pods/BLink2)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

BLink2 is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'BLink2'
```

## Author

IGitGotIt, jshah.jshah@gmail.com

## License

BLink2 is available under the MIT license. See the LICENSE file for more info.
